import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";


interface Props {
  children: React.ReactNode;
}

export default function AdminLayout({
  children,
}: Props) {


  return (
    <div className="flex min-h-screen bg-gray-100">

      {/* Sidebar */}
      
     <Sidebar />

      {/* Main Content */}
      <div className="flex-1 lg:ml-72">

        <Topbar />

        <main className="p-8">

          {children}

        </main>

      </div>

    </div>
  );
}