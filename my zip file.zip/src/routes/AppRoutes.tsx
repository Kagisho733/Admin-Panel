import { Routes, Route, Navigate } from "react-router-dom";
import LoginPage from "../pages/auth/LoginPage";
import Dashboard from "../pages/Dashboard";
import ProtectedRoute from "./ProtectedRoute";
import ProductsPage from "../pages/products/ProductsPage";
import CategoriesPage from "../pages/categories/CategoriesPage";
import OrdersPage from "../pages/orders/OrdersPage";
import UsersPage from "../pages/users/UsersPage";
import AnalyticsPage from "../pages/analytics/AnalyticsPage";
import AdminLayout from "../layouts/AdminLayout";


export default function AppRoutes() {

  return (

<Routes>

  <Route
  path="/"
  element={<Navigate to="/dashboard" replace />}
/>

  <Route
    path="/login"
    element={<LoginPage />}
  />

<Route
  path="/dashboard"
  element={
    <ProtectedRoute>
      <AdminLayout>
        <Dashboard />
      </AdminLayout>
    </ProtectedRoute>
  }
/>


<Route
  path="/products"
  element={
    <ProtectedRoute>
        <AdminLayout>
      <ProductsPage />
      </AdminLayout>
    </ProtectedRoute>
  }
/>

<Route
  path="/categories"
  element={
    <ProtectedRoute>
        <AdminLayout>
      <CategoriesPage />
        </AdminLayout>
    </ProtectedRoute>
  }
/>

<Route
  path="/orders"
  element={
    <ProtectedRoute>
        <AdminLayout>
      <OrdersPage />
        </AdminLayout>
    </ProtectedRoute>
  }
/>

<Route
  path="/users"
  element={
    <ProtectedRoute>
        <AdminLayout>
      <UsersPage />
        </AdminLayout>
    </ProtectedRoute>
  }
/>

<Route
  path="/analytics"
  element={
    <ProtectedRoute>
        <AdminLayout>
      <AnalyticsPage />
        </AdminLayout>
    </ProtectedRoute>
  }
/>


  

</Routes>



  );

}