import {

    useEffect,

    useState,

} from "react";

import type { ReactNode } from "react";

import type { AuthUser } from "../types/AuthUser";

import { AuthContext } from "./AuthContext";

import {

    login as loginService,

    logout as logoutService,

} from "../services/authService";


import {

  onAuthStateChanged,

} from "firebase/auth";

import { auth } from "../firebase/config";

interface Props {

    children: ReactNode;

}

export default function AuthProvider({

    children,

}: Props) {

const [

  user,

  setUser,

] = useState<AuthUser | null>(null);

const [

  loading,

  setLoading,

] = useState(true);


useEffect(() => {

  const unsubscribe =

    onAuthStateChanged(

      auth,

      (firebaseUser) => {

        if (firebaseUser) {
setUser({
  uid: firebaseUser.uid,
  email: firebaseUser.email ?? "",
  displayName: firebaseUser.displayName ?? "",
  role: "admin", // temporary until we read it from Firestore
});

        } else {

          setUser(null);

        }

        setLoading(false);

      }

    );

  return unsubscribe;

}, []);

    async function login(

        email: string,

        password: string

    ) {

        await loginService(

            email,

            password

        );

    }

    async function logout() {

        await logoutService();

    }

  if (loading) {

  return (

    <div className="flex h-screen items-center justify-center">

      <div className="text-lg font-medium">

        Loading...

      </div>

    </div>

  );

}

return (

  <AuthContext.Provider

    value={{

      user,

      loading,

      login,

      logout,

    }}

  >

    {children}

  </AuthContext.Provider>

);

}